-- 002_add_mesh_support.sql
----------------------------------------------------------------------------------
-- Add mesh networking support to Ground Stations
--
-- Changes:
-- - Add mesh networking columns to Groundstations table
-- - Add index for mesh station lookups
----------------------------------------------------------------------------------

-- Add mesh networking columns to Groundstations table
ALTER TABLE Satellites ADD COLUMN dopplerShiftFreq REAL NOT NULL DEFAULT 0.0;