-- 001_initial_schema.sql
----------------------------------------------------------------------------------
-- SQLite Database Schema for Satellite Ground Station Management System
--
-- Tables:
-- 1. Ground Stations (physical stations)
-- 2. Ground Station Servers (server instances)
-- 3. Packets (received data packets)
--
-- Note: Requires Satellites table (not shown in this schema)
----------------------------------------------------------------------------------

-- Enable foreign key support
PRAGMA foreign_keys = ON;

---------------------------
-- Migration Tracking Table
---------------------------
CREATE TABLE IF NOT EXISTS _migrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    applied_at INTEGER DEFAULT (strftime('%s', 'now'))
);

---------------------------
-- Ground Stations Table
---------------------------
CREATE TABLE IF NOT EXISTS Groundstations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- Basic information
    name TEXT NOT NULL,                      -- Friendly name of the ground station
    ip TEXT NOT NULL,                        -- IP address for communication
    comPort INTEGER NOT NULL,                -- Communication port number
    -- Geographic location
    latitude REAL NOT NULL,                  -- Latitude in degrees (-90 to 90)
    longitude REAL NOT NULL,                 -- Longitude in degrees (-180 to 180)
    altitude REAL NOT NULL,                  -- Altitude in meters above sea level

    -- Frequency range capabilities
    maxListeningFrequency REAL NOT NULL,     -- Maximum frequency in MHz
    minListeningFrequency REAL NOT NULL,     -- Minimum frequency in MHz

    -- Timestamps (stored as Unix timestamp)
    createdAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updatedAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    -- Unique constraint
    UNIQUE (name, ip, comPort)
 );

---------------------------
-- Ground Station Servers Table
---------------------------
CREATE TABLE IF NOT EXISTS GroundstationServers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- Basic information
    name TEXT NOT NULL,                      -- Server instance name
    ip TEXT NOT NULL,                        -- Server IP address
    comPort INTEGER NOT NULL,                -- Communication port
    apiPort INTEGER NOT NULL,                -- API endpoint port

    -- Relationships
    groundstationId INTEGER NOT NULL,        -- Link to parent ground station

    -- Timestamps
    createdAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updatedAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    -- Foreign key constraints
    FOREIGN KEY (groundstationId)
    REFERENCES Groundstations(id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,

    -- Unique constraint
    UNIQUE (groundstationId,comPort, apiPort)
    );

---------------------------
-- Packets Table
---------------------------
CREATE TABLE IF NOT EXISTS Packets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- Packet identification
    packetId TEXT NOT NULL,                  -- Unique packet identifier
    satelliteId INTEGER NOT NULL,            -- Source satellite

    -- Packet data
    rawData TEXT NOT NULL,                   -- Raw packet data
    decodedData TEXT,                        -- Decoded packet content as JSON string
    packetSize INTEGER NOT NULL DEFAULT 0,   -- Size of packet in bytes

    -- Reception metadata
    receivedAt INTEGER NOT NULL,             -- Time of packet reception (Unix timestamp)
    groundstationId INTEGER,                 -- Receiving ground station
    rssi REAL,                              -- Received Signal Strength Indicator
    snr REAL,                               -- Signal-to-Noise Ratio

    -- Satellite position at reception
    satelliteLatitude REAL DEFAULT 0,        -- Satellite latitude at reception
    satelliteLongitude REAL DEFAULT 0,       -- Satellite longitude at reception
    satelliteAltitude REAL DEFAULT 0,        -- Satellite altitude at reception
    satelliteAzimuth REAL,                  -- Satellite azimuth from ground station
    satelliteElevation REAL,                -- Satellite elevation from ground station

    -- Tracking data
    satelliteGroundTrackSpeed REAL DEFAULT 0, -- Ground track speed in km/h
    satelliteSlantRange REAL DEFAULT 0,      -- Distance to satellite in km

    -- Timestamps
    createdAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updatedAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    -- Foreign key constraints
    FOREIGN KEY (satelliteId)
    REFERENCES Satellites(id)
    ON UPDATE CASCADE
    ON DELETE CASCADE,
    FOREIGN KEY (groundstationId)
    REFERENCES Groundstations(id)
    ON UPDATE CASCADE
    ON DELETE SET NULL,

    -- Unique constraint
    UNIQUE (packetId, satelliteId, receivedAt)
    );


---------------------------
-- Satellites Table
---------------------------
CREATE TABLE IF NOT EXISTS Satellites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    -- Basic satellite information
    name TEXT NOT NULL,                      -- Name of the satellite
    noradId TEXT NOT NULL,                   -- NORAD ID for tracking
    frequency REAL NOT NULL,                 -- Operating frequency

    -- TLE (Two-Line Element) Data
    tleLine1 TEXT NOT NULL,                  -- First line of TLE
    tleLine2 TEXT NOT NULL,                  -- Second line of TLE

    -- Position vectors (ECI coordinates)
    positionX REAL,                         -- X position in km
    positionY REAL,                         -- Y position in km
    positionZ REAL,                         -- Z position in km

    -- Velocity vectors (ECI coordinates)
    velocityX REAL,                         -- X velocity in km/s
    velocityY REAL,                         -- Y velocity in km/s
    velocityZ REAL,                         -- Z velocity in km/s

    -- Geographic position
    longitude REAL,                         -- Current longitude
    latitude REAL,                          -- Current latitude
    altitude REAL,                          -- Current altitude in km

    -- LoRa radio configuration
    bandwidth REAL,                         -- Radio bandwidth in kHz
    spreadingFactor INTEGER,                -- LoRa spreading factor
    codingRate INTEGER,                     -- LoRa coding rate
    preambleLength INTEGER,                 -- Preamble length
    syncWord TEXT,                          -- Sync word for radio
    power INTEGER,                          -- Transmission power
    radioType TEXT,                         -- Type of radio being used
    decoder TEXT NOT NULL DEFAULT 'Default', -- Decoder to use for packets

    -- Tracking info
    lastUpdated INTEGER,                    -- Last position update (Unix timestamp)

    -- Timestamps
    createdAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updatedAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    -- Unique constraint for satellite identification
    UNIQUE (name, noradId, frequency)
);

---------------------------
-- Indexes
---------------------------
-- Ground Stations indexes
CREATE INDEX IF NOT EXISTS idx_groundstations_name ON Groundstations(name);
CREATE INDEX IF NOT EXISTS idx_groundstations_ip ON Groundstations(ip);

-- Ground Station Servers indexes
CREATE INDEX IF NOT EXISTS idx_groundstationservers_name ON GroundstationServers(name);
CREATE INDEX IF NOT EXISTS idx_groundstationservers_ip ON GroundstationServers(ip);
CREATE INDEX IF NOT EXISTS idx_groundstationservers_gsid ON GroundstationServers(groundstationId);

-- Packets indexes
CREATE INDEX IF NOT EXISTS idx_packets_packetid ON Packets(packetId);
CREATE INDEX IF NOT EXISTS idx_packets_satelliteid ON Packets(satelliteId);
CREATE INDEX IF NOT EXISTS idx_packets_groundstationid ON Packets(groundstationId);
CREATE INDEX IF NOT EXISTS idx_packets_receivedat ON Packets(receivedAt);

-- Indexes for Satellites table
CREATE INDEX IF NOT EXISTS idx_satellites_name
    ON Satellites(name);
CREATE INDEX IF NOT EXISTS idx_satellites_norad
    ON Satellites(noradId);
CREATE INDEX IF NOT EXISTS idx_satellites_freq
    ON Satellites(frequency);
CREATE INDEX IF NOT EXISTS idx_satellites_updated
    ON Satellites(lastUpdated);
---------------------------
-- Triggers for timestamp updates
---------------------------
CREATE TRIGGER IF NOT EXISTS groundstations_update_trigger
AFTER UPDATE ON Groundstations FOR EACH ROW
BEGIN
UPDATE Groundstations
SET updatedAt = strftime('%s', 'now')
WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS groundstationservers_update_trigger
AFTER UPDATE ON GroundstationServers FOR EACH ROW
BEGIN
UPDATE GroundstationServers
SET updatedAt = strftime('%s', 'now')
WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS packets_update_trigger
AFTER UPDATE ON Packets FOR EACH ROW
BEGIN
UPDATE Packets
SET updatedAt = strftime('%s', 'now')
WHERE id = NEW.id;
END;

CREATE TRIGGER IF NOT EXISTS satellites_update_trigger
AFTER UPDATE ON Satellites FOR EACH ROW
BEGIN
UPDATE Satellites
SET updatedAt = strftime('%s', 'now')
WHERE id = NEW.id;
END;
---------------------------
-- Views
---------------------------
CREATE VIEW IF NOT EXISTS v_active_groundstations AS
SELECT g.*,
       COUNT(p.id) as packet_count,
       MAX(p.receivedAt) as last_packet_received,
       datetime(g.createdAt, 'unixepoch') as created_date,
       datetime(g.updatedAt, 'unixepoch') as updated_date
FROM Groundstations g
         LEFT JOIN Packets p ON g.id = p.groundstationId
GROUP BY g.id;

CREATE VIEW IF NOT EXISTS v_packet_statistics AS
SELECT
    groundstationId,
    COUNT(*) as total_packets,
    AVG(rssi) as avg_rssi,
    AVG(snr) as avg_snr,
    datetime(MIN(receivedAt), 'unixepoch') as first_packet,
    datetime(MAX(receivedAt), 'unixepoch') as last_packet
FROM Packets
GROUP BY groundstationId;

CREATE VIEW IF NOT EXISTS v_active_satellites AS
SELECT
    s.*,
    datetime(s.lastUpdated, 'unixepoch') as last_updated_date,
    datetime(s.createdAt, 'unixepoch') as created_date,
    datetime(s.updatedAt, 'unixepoch') as updated_date,
    (SELECT COUNT(*) FROM Packets p WHERE p.satelliteId = s.id) as total_packets,
    (SELECT MAX(receivedAt) FROM Packets p WHERE p.satelliteId = s.id) as last_packet_received
FROM Satellites s;