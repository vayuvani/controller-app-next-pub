-- 002_add_satellite_soft_delete.sql
----------------------------------------------------------------------------------
-- Add columns to Satellites table (without constraints)
ALTER TABLE Satellites ADD COLUMN transmitterId TEXT;
ALTER TABLE Satellites ADD COLUMN isActive BOOLEAN NOT NULL DEFAULT true;
ALTER TABLE Satellites ADD COLUMN deactivatedAt INTEGER DEFAULT NULL;

-- Create a unique index instead of column constraint
CREATE UNIQUE INDEX IF NOT EXISTS idx_satellites_transmitterid_unique ON Satellites(transmitterId);

-- Create trigger to generate satellite transmitterId
CREATE TRIGGER IF NOT EXISTS satellites_after_insert
AFTER INSERT ON Satellites
WHEN NEW.transmitterId IS NULL
BEGIN
UPDATE Satellites
SET transmitterId = 'S-' || substr(hex(randomblob(4)), 1, 8)
WHERE id = NEW.id;
END;

-- Create trigger for soft delete
CREATE TRIGGER IF NOT EXISTS satellites_before_delete
BEFORE DELETE ON Satellites
BEGIN
UPDATE Satellites
SET isActive = false,
    deactivatedAt = strftime('%s', 'now')
WHERE id = OLD.id;
SELECT RAISE(IGNORE);
END;

-- Create index for status
CREATE INDEX IF NOT EXISTS idx_satellites_active_status ON Satellites(isActive, deactivatedAt);

----------------------------------------------------------------------------------
-- 003_create_ground_transmitters.sql
----------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS GroundTransmitters (
                                                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                                                  transmitterId TEXT NOT NULL,
                                                  name TEXT NOT NULL,
                                                  isActive BOOLEAN NOT NULL DEFAULT true,
                                                  deactivatedAt INTEGER DEFAULT NULL,

    -- LoRa radio configuration
                                                  bandwidth REAL,
                                                  spreadingFactor INTEGER,
                                                  codingRate INTEGER,
                                                  preambleLength INTEGER,
                                                  syncWord TEXT,
                                                  power INTEGER,
                                                  frequency REAL,

    -- Timestamps
                                                  createdAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
    updatedAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

    UNIQUE (transmitterId),
    UNIQUE (name)
    );

-- Create ID generation trigger
CREATE TRIGGER IF NOT EXISTS groundtransmitters_after_insert
AFTER INSERT ON GroundTransmitters
WHEN NEW.transmitterId IS NULL
BEGIN
UPDATE GroundTransmitters
SET transmitterId = 'G-' || substr(hex(randomblob(4)), 1, 8)
WHERE id = NEW.id;
END;

-- Create soft delete trigger
CREATE TRIGGER IF NOT EXISTS groundtransmitters_before_delete
BEFORE DELETE ON GroundTransmitters
BEGIN
UPDATE GroundTransmitters
SET isActive = false,
    deactivatedAt = strftime('%s', 'now')
WHERE id = OLD.id;
SELECT RAISE(IGNORE);
END;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_groundtransmitters_name ON GroundTransmitters(name);
CREATE INDEX IF NOT EXISTS idx_groundtransmitters_transmitterid ON GroundTransmitters(transmitterId);
CREATE INDEX IF NOT EXISTS idx_groundtransmitters_active_status ON GroundTransmitters(isActive, deactivatedAt);

----------------------------------------------------------------------------------
-- 004_modify_packets.sql
----------------------------------------------------------------------------------
-- Drop ALL dependent views first
DROP VIEW IF EXISTS v_active_groundstations;
DROP VIEW IF EXISTS v_active_satellites;
DROP VIEW IF EXISTS v_local_groundstations;
DROP VIEW IF EXISTS v_mesh_groundstations;
DROP VIEW IF EXISTS v_packet_statistics;

-- Create new packets table
CREATE TABLE Packets_new (
                             id INTEGER PRIMARY KEY AUTOINCREMENT,
                             packetId TEXT NOT NULL,
                             transmitterId TEXT NOT NULL,

    -- Packet data
                             rawData TEXT NOT NULL,
                             decodedData TEXT,
                             packetSize INTEGER NOT NULL DEFAULT 0,

    -- Reception metadata
                             receivedAt INTEGER NOT NULL,
                             groundstationId INTEGER,
                             rssi REAL,
                             snr REAL,

    -- Satellite position data
                             satelliteLatitude REAL DEFAULT 0,
                             satelliteLongitude REAL DEFAULT 0,
                             satelliteAltitude REAL DEFAULT 0,
                             satelliteAzimuth REAL,
                             satelliteElevation REAL,
                             satelliteGroundTrackSpeed REAL DEFAULT 0,
                             satelliteSlantRange REAL DEFAULT 0,

    -- Timestamps
                             createdAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),
                             updatedAt INTEGER NOT NULL DEFAULT (strftime('%s', 'now')),

                             FOREIGN KEY (groundstationId) REFERENCES Groundstations(id) ON UPDATE CASCADE ON DELETE SET NULL
);

-- Create unique index for packets
CREATE UNIQUE INDEX IF NOT EXISTS idx_packets_unique ON Packets_new(packetId, transmitterId, receivedAt);

-- Create validation trigger
CREATE TRIGGER IF NOT EXISTS packets_before_insert
BEFORE INSERT ON Packets_new
BEGIN
SELECT CASE
           WHEN NEW.transmitterId NOT LIKE 'S-%' AND NEW.transmitterId NOT LIKE 'G-%' THEN
               RAISE(ABORT, 'Invalid transmitter ID format')
           WHEN NEW.transmitterId LIKE 'S-%' AND NOT EXISTS (
               SELECT 1 FROM Satellites
               WHERE transmitterId = NEW.transmitterId
                 AND isActive = true
                 AND deactivatedAt IS NULL
           ) THEN
               RAISE(ABORT, 'Invalid or inactive satellite transmitter ID')
           WHEN NEW.transmitterId LIKE 'G-%' AND NOT EXISTS (
               SELECT 1 FROM GroundTransmitters
               WHERE transmitterId = NEW.transmitterId
                 AND isActive = true
                 AND deactivatedAt IS NULL
           ) THEN
               RAISE(ABORT, 'Invalid or inactive ground transmitter ID')
           END;
END;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_packets_new_transmitterid ON Packets_new(transmitterId);
CREATE INDEX IF NOT EXISTS idx_packets_new_receivedat ON Packets_new(receivedAt);
CREATE INDEX IF NOT EXISTS idx_packets_new_groundstationid ON Packets_new(groundstationId);

-- Migration commands for existing data
INSERT INTO Packets_new
SELECT
    id,
    packetId,
    (SELECT transmitterId FROM Satellites WHERE Satellites.id = Packets.satelliteId) as transmitterId,
    rawData,
    decodedData,
    packetSize,
    receivedAt,
    groundstationId,
    rssi,
    snr,
    satelliteLatitude,
    satelliteLongitude,
    satelliteAltitude,
    satelliteAzimuth,
    satelliteElevation,
    satelliteGroundTrackSpeed,
    satelliteSlantRange,
    createdAt,
    updatedAt
FROM Packets;

-- Drop old table and rename new one
DROP TABLE Packets;
ALTER TABLE Packets_new RENAME TO Packets;

-- Recreate views in correct order
CREATE VIEW IF NOT EXISTS v_active_groundstations AS
SELECT
    g.*,
    COUNT(p.id) as packet_count,
    MAX(p.receivedAt) as last_packet_received,
    datetime(g.createdAt, 'unixepoch') as created_date,
    datetime(g.updatedAt, 'unixepoch') as updated_date
FROM Groundstations g
         LEFT JOIN Packets p ON g.id = p.groundstationId
GROUP BY g.id;

CREATE VIEW IF NOT EXISTS v_active_satellites AS
SELECT
    s.*,
    datetime(s.lastUpdated, 'unixepoch') as last_updated_date,
    datetime(s.createdAt, 'unixepoch') as created_date,
    datetime(s.updatedAt, 'unixepoch') as updated_date,
    (SELECT COUNT(*) FROM Packets p WHERE p.transmitterId = s.transmitterId) as total_packets,
    (SELECT MAX(receivedAt) FROM Packets p WHERE p.transmitterId = s.transmitterId) as last_packet_received
FROM Satellites s;

CREATE VIEW IF NOT EXISTS v_local_groundstations AS
SELECT
    g.*,
    COUNT(DISTINCT p.transmitterId) as unique_transmitters,
    COUNT(p.id) as total_packets,
    MAX(p.receivedAt) as last_packet_time,
    AVG(p.rssi) as avg_rssi,
    AVG(p.snr) as avg_snr
FROM Groundstations g
         LEFT JOIN Packets p ON g.id = p.groundstationId
GROUP BY g.id;

CREATE VIEW IF NOT EXISTS v_mesh_groundstations AS
    WITH RECURSIVE
    connected_stations(base_id, connected_id, depth) AS (
    -- Base case: direct connections from groundstations with packets
    SELECT DISTINCT
    g1.id as base_id,
    g2.id as connected_id,
    1 as depth
    FROM Groundstations g1
    JOIN Packets p1 ON p1.groundstationId = g1.id
    JOIN Packets p2 ON p2.transmitterId = p1.transmitterId
    JOIN Groundstations g2 ON p2.groundstationId = g2.id
    WHERE g1.id != g2.id

    UNION ALL

    -- Recursive case: find stations connected through others
    SELECT
    cs.base_id,
    g2.id,
    cs.depth + 1
    FROM connected_stations cs
    JOIN Packets p1 ON p1.groundstationId = cs.connected_id
    JOIN Packets p2 ON p2.transmitterId = p1.transmitterId
    JOIN Groundstations g2 ON p2.groundstationId = g2.id
    WHERE g2.id != cs.base_id
    AND g2.id != cs.connected_id
    AND cs.depth < 3  -- Limit depth to prevent infinite recursion
)
SELECT
    g.id as groundstation_id,
    g.name as groundstation_name,
    COUNT(DISTINCT cs.connected_id) as connected_stations_count,
    MAX(cs.depth) as max_network_depth,
    GROUP_CONCAT(DISTINCT g2.name) as connected_station_names
FROM Groundstations g
         LEFT JOIN connected_stations cs ON g.id = cs.base_id
         LEFT JOIN Groundstations g2 ON cs.connected_id = g2.id
GROUP BY g.id, g.name;

CREATE VIEW IF NOT EXISTS v_packet_statistics AS
SELECT
    p.groundstationId,
    p.transmitterId,
    CASE
        WHEN p.transmitterId LIKE 'S-%' THEN 'satellite'
        WHEN p.transmitterId LIKE 'G-%' THEN 'ground'
        END as transmitter_type,
    CASE
        WHEN p.transmitterId LIKE 'S-%' THEN
            (SELECT isActive FROM Satellites WHERE transmitterId = p.transmitterId)
        WHEN p.transmitterId LIKE 'G-%' THEN
            (SELECT isActive FROM GroundTransmitters WHERE transmitterId = p.transmitterId)
        END as is_active,
    COUNT(*) as total_packets,
    AVG(p.rssi) as avg_rssi,
    AVG(p.snr) as avg_snr,
    datetime(MIN(p.receivedAt), 'unixepoch') as first_packet,
    datetime(MAX(p.receivedAt), 'unixepoch') as last_packet
FROM Packets p
GROUP BY p.groundstationId, p.transmitterId;