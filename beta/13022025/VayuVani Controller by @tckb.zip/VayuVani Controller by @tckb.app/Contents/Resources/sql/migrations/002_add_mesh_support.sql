-- 002_add_mesh_support.sql
----------------------------------------------------------------------------------
-- Add mesh networking support to Ground Stations
--
-- Changes:
-- - Add mesh networking columns to Groundstations table
-- - Add index for mesh station lookups
----------------------------------------------------------------------------------

-- Add mesh networking columns to Groundstations table
ALTER TABLE Groundstations ADD COLUMN is_mesh_connected BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE Groundstations ADD COLUMN mesh_station_id TEXT DEFAULT '';
ALTER TABLE Groundstations ADD COLUMN mesh_station_shared_key TEXT DEFAULT '';
ALTER TABLE Groundstations ADD COLUMN mesh_ip TEXT DEFAULT '';
ALTER TABLE Groundstations ADD COLUMN mesh_conn_string_enc TEXT DEFAULT '';

-- Add index for mesh station lookups
CREATE INDEX IF NOT EXISTS idx_groundstations_mesh_station
    ON Groundstations(mesh_station_id)
    WHERE is_mesh_connected = TRUE;

-- Create view for mesh-connected ground stations
CREATE VIEW IF NOT EXISTS v_mesh_groundstations AS
SELECT
    g.*,
    COUNT(p.id) as packet_count,
    MAX(p.receivedAt) as last_packet_received,
    datetime(g.createdAt, 'unixepoch') as created_date,
    datetime(g.updatedAt, 'unixepoch') as updated_date,
    (
        SELECT COUNT(DISTINCT p2.satelliteId)
        FROM Packets p2
        WHERE p2.groundstationId = g.id
    ) as unique_satellites_tracked
FROM Groundstations g
         LEFT JOIN Packets p ON g.id = p.groundstationId
WHERE g.is_mesh_connected = TRUE
GROUP BY g.id;

-- Create view for local (non-mesh) ground stations
CREATE VIEW IF NOT EXISTS v_local_groundstations AS
SELECT
    g.*,
    COUNT(p.id) as packet_count,
    MAX(p.receivedAt) as last_packet_received,
    datetime(g.createdAt, 'unixepoch') as created_date,
    datetime(g.updatedAt, 'unixepoch') as updated_date,
    (
        SELECT COUNT(DISTINCT p2.satelliteId)
        FROM Packets p2
        WHERE p2.groundstationId = g.id
    ) as unique_satellites_tracked
FROM Groundstations g
         LEFT JOIN Packets p ON g.id = p.groundstationId
WHERE g.is_mesh_connected = FALSE
GROUP BY g.id;